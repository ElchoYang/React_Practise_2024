
const NotFoundView = () => {
    return (
        <>
            Not Found
        </>
    )
}


export default NotFoundView;