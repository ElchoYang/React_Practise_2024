const AboutView = () => {
    return (
        <>
            AboutView
        </>
    )
}

export default AboutView;