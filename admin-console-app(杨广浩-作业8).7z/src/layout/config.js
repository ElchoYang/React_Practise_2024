export const NAV_WIDTH = 180
export const NAV_COLLAPSED_WIDTH = 90

export const HEADER_HEIGHT = 75
