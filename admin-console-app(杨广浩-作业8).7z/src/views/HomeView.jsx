const HomeView = () => {
    return (
        <>
            Home
        </>
    )
}

export default HomeView;