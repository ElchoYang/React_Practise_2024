export const getLoginNameAPI = () => {
  return new Promise((resolve, rejct) => {
    setTimeout(() => {
      return resolve("Admin Console App");
    }, 1000);
  });
};
