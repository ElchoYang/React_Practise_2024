import React, { useState, useRef } from 'react'
import LoginHeader from './LoginFormHeader'
import SubmitMessage from './SubmitMessage'


const LoginForm = () => {
    const accountRef = useRef(null)
    const passwordRef = useRef(null)
    const [errorMsg, seterrorMsg] = useState({
        message: '',
        color: ''
    })

    const onSubmit = () => {
        if (accountRef.current.value == 'tom' && passwordRef.current.value == '123') {
            seterrorMsg({
                message: '登录成功',
                color: 'green'
            })
        } else {
            seterrorMsg({
                message: '用户名或密码错！',
                color: 'red'
            })
        }
    }

    return (
        <>
            <div className="LoginContainer">
                <LoginHeader />
                <form className="Loginform">
                    <input type='text' name="account" ref={accountRef} placeholder="admin"   ></input>
                    <input type="password" name="password" ref={passwordRef} placeholder="***"   ></input>
                    <button type='button' onClick={onSubmit} >Submit</button>
                    <SubmitMessage value={errorMsg} />
                </form>
            </div >
        </>
    )
};

export default LoginForm;