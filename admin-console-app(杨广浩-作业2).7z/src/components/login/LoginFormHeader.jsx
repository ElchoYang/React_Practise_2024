import { useState, useEffect } from 'react'
import { getLoginNameAPI } from '../../API/loginAPI'


const LoginHeader = () => {
  const [systemName, setsystemName] = useState('')

  useEffect(() => {
    getSystemName()
  })

  const getSystemName = () => {
    getLoginNameAPI().then(res => {
      setsystemName(res)
    })
  }
  return (
    <>
      <h3>{systemName}</h3>
    </>
  );
};

export default LoginHeader;
