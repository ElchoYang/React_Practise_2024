import logo from "./logo.svg";
import "./App.css";
import LoginView from "./views/LoginView";

function App() {
  return (
    <div className="App">
      <LoginView />
    </div>
  );
}

export default App;
