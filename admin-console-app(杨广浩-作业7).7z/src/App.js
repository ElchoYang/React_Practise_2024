import logo from "./logo.svg";
import "./App.css";
import LoginView from "./views/login/LoginView";

function App() {
  return (
    <div className="App">
      <LoginView />
    </div>
  );
}

export default App;
