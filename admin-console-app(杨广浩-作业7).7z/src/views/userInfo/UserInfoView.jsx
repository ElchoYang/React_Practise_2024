

const UserInfoView = () => {

    return (
        <>
            User Info
        </>
    )
}


export default UserInfoView